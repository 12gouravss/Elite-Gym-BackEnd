package in.darshan.elite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EliteFitApplicationTests {

	@Test
	void contextLoads() {
	}

}
