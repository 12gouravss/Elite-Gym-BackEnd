package in.gourav.elite.request;

import lombok.Data;

@Data
public class OrderUpdate {
	
	private Integer id;
	private String status;

}
