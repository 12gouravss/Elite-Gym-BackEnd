package in.gourav.elite.request;

import lombok.Data;

@Data
public class contactUpdateRequest {
	
	private Integer id;
	private String status;

}
