package in.gourav.elite.service;

import java.util.List;

import in.gourav.elite.DTO.AdminOrderItemDTO;
import in.gourav.elite.DTO.ProductQuantityDTO;
import in.gourav.elite.DTO.UserOrderDTO;
import in.gourav.elite.entity.MemberShip;
import in.gourav.elite.entity.OrderItem;
import in.gourav.elite.entity.Orders;
import in.gourav.elite.entity.Product;
import in.gourav.elite.response.AdminOrders;

public interface OrderServices {



	public Integer placeOrder(Orders order, List<OrderItem> orderItems);



	public List<ProductQuantityDTO> getProduct(Integer id);

	public boolean updateRating(Integer productId, Double rating);

	public Integer getTodaySales();

	

	public List<AdminOrderItemDTO> getOrderItems();

	public Orders getOrder(Integer id);

	public void updateStatus(Orders order);

	public List<UserOrderDTO> getOrderIdStatus(Integer userId);

}
