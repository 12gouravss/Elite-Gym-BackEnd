package in.gourav.elite.utils;

import com.razorpay.Order;
import com.razorpay.Payment;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;

@Service
public class RazorpayService {

    @Value("${razorpay.key.id}")
    private String keyId;

    @Value("${razorpay.key.secret}")
    private String keySecret;

    private RazorpayClient getClient() throws Exception {
        return new RazorpayClient(keyId, keySecret);
    }

    /**
     * Create a new Razorpay Order
     */
    public Order createOrder(int amountInPaise, String currency, String receipt) throws Exception {
        RazorpayClient client = getClient();

        JSONObject orderRequest = new JSONObject();
        orderRequest.put("amount", amountInPaise); // amount in paise
        orderRequest.put("currency", currency);
        orderRequest.put("receipt", receipt);
        orderRequest.put("payment_capture", 1);

        return client.orders.create(orderRequest);
    }

    /**
     * Fetch an existing Razorpay Order
     */
    public Order fetchOrder(String orderId) throws Exception {
        RazorpayClient client = getClient();
        return client.orders.fetch(orderId);
    }

    /**
     * Fetch payment details by paymentId
     */
    public Payment fetchPayment(String paymentId) throws Exception {
        RazorpayClient client = getClient();
        return client.payments.fetch(paymentId);
    }

    /**
     * Verify Razorpay payment signature
     * (Frontend sends razorpay_order_id, razorpay_payment_id, razorpay_signature)
     */
    public boolean verifySignature(String orderId, String paymentId, String razorpaySignature) throws Exception {
        String data = orderId + "|" + paymentId;
        System.out.println(data);
        String generatedSignature = hmacSHA256(data, keySecret);
        System.out.println(generatedSignature.equals(razorpaySignature));
        return generatedSignature.equals(razorpaySignature);
    }

    private String hmacSHA256(String data, String secret) throws Exception {
        Mac sha256_HMAC = Mac.getInstance("HmacSHA256");
        SecretKeySpec secretKey = new SecretKeySpec(secret.getBytes(), "HmacSHA256");
        sha256_HMAC.init(secretKey);
        byte[] hash = sha256_HMAC.doFinal(data.getBytes());

        // Convert bytes to HEX (lowercase)
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }


    public String getKeyId() {
        return keyId;
    }
}
