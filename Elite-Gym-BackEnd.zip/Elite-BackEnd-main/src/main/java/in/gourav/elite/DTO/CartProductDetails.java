package in.gourav.elite.DTO;

import lombok.Data;

@Data
public class CartProductDetails {

	private Integer productId;
	private Integer quantity;
}
