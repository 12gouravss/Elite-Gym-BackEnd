package in.gourav.elite.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ratingCountDTO {
	
	private double count;
	private double rating;

}
