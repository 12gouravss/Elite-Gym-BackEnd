package in.gourav.elite.request;

import lombok.Data;

@Data
public class cartAddRequest {
	
	private Integer productId;
	private Integer userId;

}
