package in.gourav.elite.exception;

public class AdminException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public AdminException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
