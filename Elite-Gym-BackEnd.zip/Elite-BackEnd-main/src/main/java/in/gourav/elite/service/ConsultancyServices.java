package in.gourav.elite.service;

import java.util.List;

import in.gourav.elite.entity.Consultancy;
import in.gourav.elite.response.ConsultResponse;

public interface ConsultancyServices {
	
	public Integer book(Consultancy consultancy);

	public List<ConsultResponse> getConsultencies(Integer userId);



}
