package in.gourav.elite.service;

public interface StoreServices {
	


}
