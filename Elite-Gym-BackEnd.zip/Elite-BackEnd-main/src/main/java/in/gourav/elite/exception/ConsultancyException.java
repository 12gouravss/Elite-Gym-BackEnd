package in.gourav.elite.exception;

public class ConsultancyException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;


	public ConsultancyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}


	
	

}
