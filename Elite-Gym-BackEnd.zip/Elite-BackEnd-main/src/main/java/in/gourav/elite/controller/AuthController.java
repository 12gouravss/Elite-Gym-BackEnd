package in.gourav.elite.controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.gourav.elite.entity.User;
import in.gourav.elite.exception.UserException;
import in.gourav.elite.request.ForgotPasswordRequest;
import in.gourav.elite.request.OtpVerificationRequest;
import in.gourav.elite.request.ResetPasswordRequest;
import in.gourav.elite.request.UserSignInRequest;
import in.gourav.elite.request.UserSignUpRequest;
import in.gourav.elite.service.UserServices;
import in.gourav.elite.utils.EmailService;
import in.gourav.elite.utils.OtpService;


@RestController
@RequestMapping("/auth")
public class AuthController {
	
	@Autowired
	private UserServices services;
	
	@Autowired
	private OtpService otpService;
	
	@Autowired
	private EmailService emailService;
	
	private BCryptPasswordEncoder enCoder = new BCryptPasswordEncoder(12);
	
	
	@PostMapping("/userRegister")
	public ResponseEntity<?> userRegister(@RequestBody UserSignUpRequest user){
		
		String status = "";
		if(user.getName()==null || user.getEmail()==null || user.getPhone()==null || user.getGender()==null ||
				user.getDOB()==null || user.getAddress()==null || user.getPassword()==null) {
			System.out.println("Invalid Data");
			throw new UserException("Invalid Data");
		}
		
		User checkMail = services.getUser(user.getEmail());
		if(checkMail!=null) {
			System.out.println("Email Already Exists");
			throw new UserException("Email Already Exists"); 
		} 
		System.out.println(user.getDOB());
		
		User u = new User();
		u.setName(user.getName());
		u.setEmail(user.getEmail());
		u.setPhone(user.getPhone());
		u.setGender(user.getGender());
		u.setDOB(user.getDOB());
		u.setAddress(user.getAddress());
		u.setPassword(user.getPassword());
		u.setCreatedAt(LocalDateTime.now());
		u.setRole("USER");
		
		Integer id = services.register(u);
		Map<String, String> response = new HashMap<>();
		
		if(id>0) {
			status = "Successfully Registered";
		}
		else {
			status = "Failed To Register";
		}
		response.put("status",status);
		return ResponseEntity.ok(response);
		
	}
	
	
	
	@PostMapping("/userLogin")
	public ResponseEntity<?> login(@RequestBody UserSignInRequest user) {
		
		if(user.getEmail() == null || user.getPassword()==null) {
			throw new UserException("InValid data");
		}
		
		System.out.println(user.getEmail());
		User u = services.getUser(user.getEmail());
		if(u == null) {
			throw new UserException("EmailId Not Found");
		}
		
//		if(!enCoder.matches(user.getPassword(),u.getPassword() )) {
//			throw new UserException("Incorrect Password");
//		}
//		
		
		
		String res = services.login(user);
		Map<String, String> response = new HashMap<>();
		
		String token = res;
		String role = services.getRole(user.getEmail());
		
		
		response.put("status", "success");
		response.put("token",token);
		response.put("role", role);
		
		return ResponseEntity.ok(response);
	}
	
	
	@PostMapping("/adminRegister")
	public ResponseEntity<?> adminRegister(@RequestBody UserSignUpRequest user, @RequestParam String secretKey) {
		
		
	    if (!secretKey.equals("MY_ADMIN_SECRET_Ravana2525")) {
	        throw new RuntimeException("Unauthorized");
	    }

	    User u = new User();
	    u.setName(user.getName());
	    u.setEmail(user.getEmail());
	    u.setPhone(user.getPhone());
	    u.setGender(user.getGender());
	    u.setDOB(user.getDOB());
	    u.setAddress(user.getAddress());
	    u.setPassword(user.getPassword());
	    u.setCreatedAt(LocalDateTime.now());
	    u.setRole("ADMIN");

	    Integer id = services.register(u);
	    Map<String,String> response = new HashMap<>();
	    if(id>0) {
	    	response.put("status", "Admin Registered");
	    }else {
	    	throw new UserException("Failed to register");
	    }

	    return ResponseEntity.ok(response);
	}
	
	
	@PostMapping("/addAdmin")
	@PreAuthorize("hasRole('ADMIN')")
	public ResponseEntity<?> addAdmin(@RequestBody UserSignUpRequest user, @RequestParam String secretKey) {
	    
	    if (!secretKey.equals("MY_ADMIN_SECRET")) {
	        throw new RuntimeException("Unauthorized");
	    }
	    
	    User existing = services.getUser(user.getEmail());
	    if (existing != null) {
	        throw new UserException("Email already exists");
	    }

	    User u = new User();
	    u.setName(user.getName());
	    u.setEmail(user.getEmail());
	    u.setPhone(user.getPhone());
	    u.setGender(user.getGender());
	    u.setDOB(user.getDOB());
	    u.setAddress(user.getAddress());
	    u.setPassword(user.getPassword()); 
	    u.setCreatedAt(LocalDateTime.now());
	    u.setRole("admin");

	    
	    Integer id = services.register(u);
	    Map<String,String> response = new HashMap<>();
	    if(id>0) {
	    	response.put("status", "Admin Registered");
	    }else {
	    	throw new UserException("Failed to register");
	    }

	    return ResponseEntity.ok(response);
	}
	
	public String generateAlphaNumericOtp(int length) {
	    String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	    StringBuilder otp = new StringBuilder();

	    Random random = new Random();
	    for (int i = 0; i < length; i++) {
	        int index = random.nextInt(chars.length());
	        otp.append(chars.charAt(index));
	    }

	    return otp.toString();
	}

	
	@PostMapping("/forgotPassword")
	public ResponseEntity<?> forgotPassword(@RequestBody ForgotPasswordRequest request) {
	    String email = request.getEmail();
	    System.out.println(email);

	    // 1. Check if user exists
	    User u = services.getUser(email);
	    if (u == null) {
	        throw new UserException("Email not found.");
	    }

	    // 2. Generate OTP (e.g., 6-digit random number)
	  
	    String otp = generateAlphaNumericOtp(6);
	    
	    // 3. Save OTP in DB or in-memory store with expiry
	    otpService.saveOtp(email, otp);
	  
	    // 4. Send OTP via email
	    emailService.sendOtpEmail(email, otp);

	    return ResponseEntity.ok("OTP has been sent to your email.");
	}
	
	@PostMapping("/verifyOtp")
	public ResponseEntity<?> verifyOtp(@RequestBody OtpVerificationRequest request) {
	    boolean valid = otpService.validateOtp(request.getEmail(), request.getOtp());

	    if (!valid) {
	        throw new UserException("Invalid or expired OTP.");
	    }

	    // Optional: generate temporary token for password reset
	    String resetToken = UUID.randomUUID().toString();
	    //UUID( Universally Unique Identifier) -> 
	    // UUID uuid = UUID.randomUUID() ->generates a unique UUID 
	    //.toString->  converts it to a string
	    // This generates a random, unique string (a reset token) using Java’s built-in UUID class
	    
	    otpService.storeResetToken(request.getEmail(), resetToken);

	    return ResponseEntity.ok(Map.of("Token", resetToken));
	}

	
	@PostMapping("/newPassword")
	public ResponseEntity<?> resetPassword(@RequestBody ResetPasswordRequest request) {
	    String email = request.getEmail();
	    String token = request.getToken();
	    String newPassword = request.getNewPassword();

	    if (!otpService.validateResetToken(email, token)) {
	        throw new UserException("Time Out.");
	    }

	    // Update password in DB 
	    User user = services.getUser(email);
	    user.setPassword(enCoder.encode(newPassword));
	    services.update(user);

	 // Invalidate token after use
	    otpService.clearResetToken(email); 

	    return ResponseEntity.ok("Password reset successful.");
	}



	
	
	



}
