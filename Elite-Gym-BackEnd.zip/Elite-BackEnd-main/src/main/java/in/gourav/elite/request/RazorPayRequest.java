package in.gourav.elite.request;

import lombok.Data;

@Data
public class RazorPayRequest {
	private Integer  amount;
	private String currency;

}
