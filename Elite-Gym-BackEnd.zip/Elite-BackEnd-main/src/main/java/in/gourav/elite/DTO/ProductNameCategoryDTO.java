package in.gourav.elite.DTO;

import lombok.AllArgsConstructor;
import lombok.Data;


@Data
@AllArgsConstructor
public class ProductNameCategoryDTO {
	
	private String name;
	private String category;
	

	

}
