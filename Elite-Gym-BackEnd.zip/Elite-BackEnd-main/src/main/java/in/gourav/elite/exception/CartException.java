package in.gourav.elite.exception;


public class CartException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public CartException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
