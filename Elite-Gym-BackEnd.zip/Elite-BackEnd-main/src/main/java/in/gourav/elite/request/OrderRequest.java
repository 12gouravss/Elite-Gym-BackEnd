package in.gourav.elite.request;

import java.util.List;

import in.gourav.elite.DTO.CartProductDetails;
import lombok.Data;

@Data
public class OrderRequest {

	private String source;
	private String paymentMode;
	private Integer addressId;
	private List<CartProductDetails> cartProductDetails;
}
