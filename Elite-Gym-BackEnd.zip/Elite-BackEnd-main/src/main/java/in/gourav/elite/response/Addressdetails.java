package in.gourav.elite.response;

import lombok.Data;

@Data
public class Addressdetails {
	
	private String name;
	private Long phone;
	private String Address;

}
