package in.gourav.elite.request;

import lombok.Data;

@Data
public class ForgotPasswordRequest {
	private String email;
}
