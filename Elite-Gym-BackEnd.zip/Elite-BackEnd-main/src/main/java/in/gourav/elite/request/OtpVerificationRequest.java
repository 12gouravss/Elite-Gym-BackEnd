package in.gourav.elite.request;

import lombok.Data;

@Data
public class OtpVerificationRequest {

	private String email;
	private String otp;
}
