package in.gourav.elite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EliteFitApplication {

	public static void main(String[] args) {
		SpringApplication.run(EliteFitApplication.class, args);
	}

}
